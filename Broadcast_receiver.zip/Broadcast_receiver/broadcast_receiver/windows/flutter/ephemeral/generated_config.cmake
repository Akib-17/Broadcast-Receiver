# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Ahsan Akib\\Downloads\\flutter_windows_3.38.7-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Ahsan Akib\\Downloads\\flutter_windows_3.38.7-stable\\flutter"
  "PROJECT_DIR=C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver"
  "FLUTTER_ROOT=C:\\Users\\Ahsan Akib\\Downloads\\flutter_windows_3.38.7-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver"
  "FLUTTER_TARGET=C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuMzguNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049M2I2MmVmYzJhMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NzhmYzMwMTJlNA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMC43"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\Ahsan Akib\\OneDrive\\Desktop\\CSE489_Assignment_2-master\\broadcast_receiver\\.dart_tool\\package_config.json"
)
