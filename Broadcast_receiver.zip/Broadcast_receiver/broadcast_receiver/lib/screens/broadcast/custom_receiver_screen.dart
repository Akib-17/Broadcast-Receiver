import 'package:flutter/material.dart';
import 'dart:async';
import '../../services/broadcast_service.dart';


class CustomReceiverScreen extends StatefulWidget {
  final String? messageToSend;
  
  const CustomReceiverScreen({super.key, this.messageToSend});

  @override
  State<CustomReceiverScreen> createState() => _CustomReceiverScreenState();
}

class _CustomReceiverScreenState extends State<CustomReceiverScreen> {
  final BroadcastService _broadcastService = BroadcastService();
  final List<String> _receivedMessages = [];
  StreamSubscription<String>? _subscription;

  @override
  void initState() {
    super.initState();
    _listenToBroadcasts();
    
    if (widget.messageToSend != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _broadcastService.sendCustomBroadcast(widget.messageToSend!);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Broadcast sent successfully!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
        }
      });
    }
  }

  void _listenToBroadcasts() {
     // Subscribe
    _subscription = _broadcastService.customBroadcastStream.listen((message) {
      setState(() {
        _receivedMessages.add(message);
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Broadcast Receiver'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header
            Card(
              color: Colors.green.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green.shade700, size: 32),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Receiver Active',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.green.shade700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Listening for broadcast messages...',
                            style: TextStyle(color: Colors.green.shade900),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Title
            const Text(
              'Received Messages',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            // Messages list
            Expanded(
              child: _receivedMessages.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.inbox,
                            size: 80,
                            color: Colors.grey.shade400,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No messages received yet',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Waiting for broadcasts...',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade500,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: _receivedMessages.length,
                      itemBuilder: (context, index) {
                        final message = _receivedMessages[index];
                        final messageNumber = index + 1;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          elevation: 2,
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: Theme.of(context).colorScheme.primary,
                              child: Text(
                                '$messageNumber',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            title: Text(
                              message,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            subtitle: Text(
                              'Received at ${DateTime.now().toString().substring(11, 19)}',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            trailing: Icon(
                              Icons.done_all,
                              color: Colors.green.shade600,
                            ),
                          ),
                        );
                      },
                    ),
            ),

            // Clear button
            if (_receivedMessages.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: OutlinedButton.icon(
                  onPressed: () {
                    setState(() {
                      _receivedMessages.clear();
                    });
                  },
                  icon: const Icon(Icons.clear_all),
                  label: const Text('Clear All Messages'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
