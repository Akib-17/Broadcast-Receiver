import 'package:flutter/material.dart';
import 'custom_input_screen.dart';
import 'battery_screen.dart';

class BroadcastSelectionScreen extends StatefulWidget {
  const BroadcastSelectionScreen({super.key});

  @override
  State<BroadcastSelectionScreen> createState() =>
      _BroadcastSelectionScreenState();
}

class _BroadcastSelectionScreenState extends State<BroadcastSelectionScreen> {
  final List<String> _broadcastOptions = [
    'Custom broadcast receiver',
    'System battery notification receiver',
  ];

  String _selectedOption = 'Custom broadcast receiver';

  void _proceedToNextScreen() {
    if (_selectedOption == 'Custom broadcast receiver') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const CustomInputScreen(),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const BatteryScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Broadcast Receiver'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Title
            const Text(
              'Select Broadcast Type',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedOption,
                  isExpanded: true,
                  icon: const Icon(Icons.arrow_drop_down),
                  items: _broadcastOptions.map((String option) {
                    return DropdownMenuItem<String>(
                      value: option,
                      child: Text(option),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _selectedOption = newValue;
                      });
                    }
                  },
                ),
              ),
            ),
            const SizedBox(height: 40),

            // Proceed button
            ElevatedButton(
              onPressed: _proceedToNextScreen,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
              ),
              child: const Text(
                'Proceed',
                style: TextStyle(fontSize: 18),
              ),
            ),

            const SizedBox(height: 20),

            // Information card
            Card(
              color: Colors.blue.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.blue.shade700),
                        const SizedBox(width: 8),
                        Text(
                          'Information',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue.shade700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _selectedOption == 'Custom broadcast receiver'
                          ? 'You will be able to send a custom text message that will be received by a broadcast receiver.'
                          : 'You will see the current battery level and status of your device.',
                      style: TextStyle(color: Colors.blue.shade900),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
