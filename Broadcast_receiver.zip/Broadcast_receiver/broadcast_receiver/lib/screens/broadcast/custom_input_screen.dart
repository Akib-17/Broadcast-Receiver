import 'package:flutter/material.dart';
import 'custom_receiver_screen.dart';

/// Second screen for custom broadcast option
/// Allows user to input text that will be broadcast
class CustomInputScreen extends StatefulWidget {
  const CustomInputScreen({super.key});

  @override
  State<CustomInputScreen> createState() => _CustomInputScreenState();
}

class _CustomInputScreenState extends State<CustomInputScreen> {
  final TextEditingController _messageController = TextEditingController();
  

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _sendBroadcast() {
    final message = _messageController.text.trim();

    if (message.isEmpty) {
      // Show error if message is empty
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a message to broadcast'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Navigate to receiver screen and pass the message
    // The receiver will start listening first, then trigger the broadcast
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CustomReceiverScreen(messageToSend: message),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom Broadcast'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Icon
            Icon(
              Icons.broadcast_on_personal,
              size: 80,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 20),

            // Title
            const Text(
              'Send Custom Broadcast',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),

            // Description
            Text(
              'Enter a message to broadcast to the receiver',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),

            // Text input field
            TextField(
              controller: _messageController,
              decoration: InputDecoration(
                labelText: 'Broadcast Message',
                hintText: 'Enter your message here...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                prefixIcon: const Icon(Icons.message),
              ),
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
            ),
            const SizedBox(height: 30),

            // Send broadcast button
            ElevatedButton.icon(
              onPressed: _sendBroadcast,
              icon: const Icon(Icons.send),
              label: const Text(
                'Send Broadcast',
                style: TextStyle(fontSize: 18),
              ),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
              ),
            ),

            const SizedBox(height: 20),

            // Info card
            Card(
              color: Colors.amber.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.lightbulb_outline, color: Colors.amber.shade700),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'The message will be sent to the broadcast receiver on the next screen.',
                        style: TextStyle(color: Colors.amber.shade900),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
