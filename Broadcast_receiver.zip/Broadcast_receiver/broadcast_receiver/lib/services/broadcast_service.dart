import 'dart:async';

class BroadcastService {
  static final BroadcastService _instance = BroadcastService._internal();
  factory BroadcastService() => _instance;
  BroadcastService._internal();

  // Broadcast stream controller for custom messages
  final StreamController<String> _customBroadcastController =
      StreamController<String>.broadcast();

  /// Stream to listen for custom broadcast messages
  Stream<String> get customBroadcastStream => _customBroadcastController.stream;

  /// Send a custom broadcast message
  void sendCustomBroadcast(String message) {
    _customBroadcastController.sink.add(message);
  }

  void dispose() {
    _customBroadcastController.close();
  }
}
